criaCartao(
//categoria,
'Programação',
//pergunta,
'O que é JavaScript?',
//resposta,
'o JavaScript é uma línguagem de programação'

)

criaCartao(
 //categoria,
 'Programação',
 //pergunta,
 'O que é JavaScript?',
 //resposta,
'o JavaScript é uma línguagem de programação'
    
)

 criaCartao(
 //categoria,
'Programação',
 //pergunta,
 'O que é JavaScript?',
 //resposta,
 'o JavaScript é uma línguagem de programação'
        
 )
 criaCartao(
    'Literatura',
    'Qual é o nome da Saga de Camily Antonnely',
    'O nome é Luzes do Inverno'
 )